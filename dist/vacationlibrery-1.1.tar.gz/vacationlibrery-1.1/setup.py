from distutils.core import setup

setup(name='vacationlibrery',
      version='1.1',
      author='Mateusz Wojcik',
      author_email='226611@student.pwr.edu.pl',
      url='https://github.com/BombaGR',
      packages=['myPackage'],
      )
