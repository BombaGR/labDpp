from distutils.core import setup

setup(name='vacationlibrery',
      version='1.0',
      author='Mateusz Wojcik',
      author_email='226611@student.pwr.edu.pl',
      url='https://github.com/BombaGR',
      )
